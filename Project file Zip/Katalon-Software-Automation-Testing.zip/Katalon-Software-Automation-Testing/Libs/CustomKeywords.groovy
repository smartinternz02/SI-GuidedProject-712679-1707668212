
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "com.katalon.test.KeywordElement.CheckDropElementKatalon"(
    	TestObject object	
     , 	String option	) {
    (new com.katalon.test.KeywordElement()).CheckDropElementKatalon(
        	object
         , 	option)
}
